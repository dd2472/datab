package com.dnapass.training.javaee.entity;

import java.io.Serializable;
import java.util.Map;

//@Entity
//@Table(name="WEB_BOOKSTORE_BOOKS")
public class BookTwo implements Serializable {
    
	private String bookId;
	private String description;
	private String firstName;
	private String surName;
	private String title;
	private boolean onSale;
	private float price;
	private int calender_year;
	private int inventory;
	private Map map;
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public boolean isOnSale() {
		return onSale;
	}
	public void setOnSale(boolean onSale) {
		this.onSale = onSale;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getCalender_year() {
		return calender_year;
	}
	public void setCalender_year(int calender_year) {
		this.calender_year = calender_year;
	}
	public int getInventory() {
		return inventory;
	}
	public void setInventory(int inventory) {
		this.inventory = inventory;
	}
	public Map getMap() {
		return map;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	
}
