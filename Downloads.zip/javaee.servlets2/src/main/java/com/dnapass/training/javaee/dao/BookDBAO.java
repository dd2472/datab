package com.dnapass.training.javaee.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.dnapass.training.javaee.entity.Book;
import com.dnapass.training.javaee.exception.BookNotFoundException;
import com.dnapass.training.javaee.exception.BooksNotFoundException;
import com.dnapass.training.javaee.exception.OrderException;
import com.dnapass.training.javaee.model.ShoppingCart;
import com.dnapass.training.javaee.model.ShoppingCartItem;

public class BookDBAO {
	private Connection con;

	public BookDBAO(Connection connArg) {
		super();
		this.con = connArg;
	}

	public void createTable() throws SQLException {
		String createString = "create table WEB_BOOKSTORE_BOOKS " + "(bookId VARCHAR (8)," + "surname VARCHAR(24), "
				+ "firstName VARCHAR (24), " + "title VARCHAR(96), " + "price FLOAT, " + "onSale SMALLINT, "
				+ "calendar_year INT, " + "description VARCHAR (30), inventory INT, " + "PRIMARY KEY (bookId) " + ")";
		try (Statement stmt = con.createStatement()) {
			stmt.executeUpdate(createString);
		} catch (SQLException e) {
			JDBCUtil.printSQLException(e);
		}
	}

	public void populateTable() throws SQLException {
		try (Statement stmt = con.createStatement()) {
			stmt.executeUpdate("insert into WEB_BOOKSTORE BOOKS"
					+ "VALUES ('201', 'Duke', '', 'My Early Years: Growing up on *7', 30.75, 0, 1995, 'What a cool book. ',20)");
			stmt.executeUpdate("insert into WEB_BOOKSTORE_BOOKS "
					+ "VALUES ('282', 'Jeeves', 'Web Servers for Fun and Profit', 40.75, 1, 2000, 'What a cool book. ',20)");
			stmt.executeUpdate("insert into WEB_BOOKSTORE BOOKS"
					+ "VALUES ('203', 'Masterson' 'Webster' Web Components for Web Developers', 27.75, 0, 2000, 'What a cool book. ',20)");
			stmt.executeUpdate("insert into WEB_BOOKSTORE BOOKS"
					+ "VALUES ('205', 'Novation', 'Kevin', From Oak to Java: The Revolution of Language', 10.75, 1, 1998,'What a cool book. ',20)");
			stmt.executeUpdate("insert into WEB_BOOKSTORE BOOKS "
					+ "VALUES ('206', 'Gosling', 'James', Intermediate Bytecodes', 30.95, 1, 2000, 'What a cool book. ',20)");
			stmt.executeUpdate("insert into WEB_BOOKSTORE BOOKS"
					+ "VALUES (207', 'Thrilled, TBen', 'The Green Project: Programming for Consumer Devices', 30.00, 1, 1998, 'What a cool book' , 20)");
			stmt.executeUpdate("insert into WEB_BUOKSTORE BOOKS"
					+ "VALUES('208 'Tru', 'Itzal', 'Duke: A Biography of the Java Evangelist', 45.00, 0, 2001, 'What a cool book. ',20)");
		} catch (SQLException e) {
			JDBCUtil.printSQLException(e);
		}
	}

	public void dropTable() throws SQLException {
		try (Statement stmt = con.createStatement()) {
			stmt.executeUpdate("DROP TABLE IF EXISTS COFFEES");
		} catch (SQLException e) {
			JDBCUtil.printSQLException(e);
		}
	}

	public void viewTable() throws SQLException {
		String query = "select bookId, description, firstName, surname, title,onSale, price, calendar_year, inventory from WEB_BOOKSTORE_BOOKS";
		try (Statement stmt = con.createStatement()) {
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String bookId = rs.getString("bookId");
				String description = rs.getString("description");
				String firstName = rs.getString("firstName");
				String surname = rs.getString("surname");
				String title = rs.getString("title");
				boolean onSale = rs.getBoolean("onSale");
				float price = rs.getFloat("price");
				int calendar_year = rs.getInt("calendar_year");
				int inventory = rs.getInt("inventory");
				System.out.println(bookId + ", " + description + ", " + firstName + ", " + surname + ", " + title + ", "
						+ onSale + ", " + price + ", " + calendar_year + ", " + inventory);
			}
		} catch (SQLException e) {
			JDBCUtil.printSQLException(e);
		}
	}

	public List getBooks() throws BooksNotFoundException {
		try {
			// return em.createQuery("SELECT bd FROM Book bd ORDER BY
			// bd .bookName").getResultList();
			return findAll();
		} catch (Exception ex) {
			throw new BooksNotFoundException("Could not get books: " + ex.getMessage());
		}
	}

	/*
	 * 
	 * private String bookId; private ring description; private String firstName; *
	 * private String surname; private String title; private boolean onSale; private
	 * * float price; private int calendar_year; private int inventory;
	 */
	public List<Book> findAll() throws SQLException {
		String query = "select bookId, description, firstName, surname, title, onSale, price, calendar_year, inventary from WEB_BOOKSTORE_BOOKS";
		List<Book> books = new ArrayList<>();
		try (Statement stmt = con.createStatement()) {
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String bookId = rs.getString("bookId");
				String description = rs.getString("description");
				String firstName = rs.getString("firstName");
				String surName = rs.getString("surName");
				String title = rs.getString("title");
				boolean onSale = rs.getBoolean("onSale");
				float price = rs.getFloat("price");
				int calendar_year = rs.getInt("calendar_year");
				int inventory = rs.getInt("inventory");
				Book book = new Book(bookId, description, firstName, surName, title, price, onSale, calendar_year,
						inventory);
				books.add(book);
				System.out.println(bookId + ", " + description + ", " + firstName + ", " + surName + ", " + title + ", "
						+ onSale + ", " + price + ", " + calendar_year + ", " + inventory);
			}
		} catch (SQLException e) {
			JDBCUtil.printSQLException(e);
		}
		return books;
	}

	public Book getBook(String bookId) throws BookNotFoundException {
		Book requestedBook;
		try {
			requestedBook = findBook(bookId);
		} catch (SQLException e) {
			throw new BookNotFoundException("Couldn't find book: " + bookId);
		}
		if (requestedBook == null) {
			throw new BookNotFoundException("Couldn't find book: " + bookId);
		}
		return requestedBook;
	}

	public Book findBook(String bookId) throws SQLException {
		String query = "select bookId, description, firstName, surname, title, onSale, price, calendar_year, inventory from WEB_BOOKSTORE_BOOKS where bookId="
				+ bookId;
		Book book = null;
		try (Statement stmt = con.createStatement()) {
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				bookId = rs.getString("bookId");
				String description = rs.getString("description");
				String firstName = rs.getString("firstName");
				String surname = rs.getString("surName");
				String title = rs.getString("title");
				boolean onSale = rs.getBoolean("onSale");
				float price = rs.getFloat("price");
				int calendar_year = rs.getInt("calendar_year");
				int inventory = rs.getInt("inventory");
				book = new Book(bookId, description, firstName, surName, title, price, onSale, calendar_year,
						inventory);
				System.out.println(bookId + ", " + description + ", " + firstName + ", " + surName + ", " + title + ", "
						+ onSale + ", " + price + ", " + calendar_year + ", " + inventory);
			}
		} catch (SQLException e) {
			JDBCUtil.printSQLException(e);
		}
		return book;
	}

	public void buyBooks(ShoppingCart cart) throws OrderException {
		Collection items = cart.getItems();
		Iterator i = items.iterator();
		try {
			while (i.hasNext()) {
				ShoppingCartItem sci = (ShoppingCartItem) i.next();
				Book bd = (Book) sci.getItem();
				String id = bd.getBookId();
				int quantity = sci.getQuantity();
				buyBook(id, quantity);
			}
		} catch (Exception ex) {
			throw new OrderException("Commit failed: " + ex.getMessage());
		}
	}

	public void buyBook(String bookId, int quantity) throws OrderException {
		try {
			Book requestedBook = findBook(bookId);
			if (requestedBook != null) {
				int inventory = requestedBook.getInventory();
				if ((inventory - quantity) >= 0) {
					int newInventory = inventory - quantity;
					requestedBook.setInventory(newInventory);
				} else {
					throw new OrderException("Not enough " + bookId + " in stock to complete order.");
				}
			}
		} catch (Exception ex) {
			throw new OrderException("Couldn't purchase book: " + bookId + ex.getMessage());
		}
	}
}
