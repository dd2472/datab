package com.dnapass.training.javaee.exception;

/**
 * 
 * This appication exception indicates that a book has not been found
 */

public class BookNotFoundException extends Exception {
	//
	public BookNotFoundException() {
		
	}
	public BookNotFoundException(String msg) {
		super(msg);
	}

}
