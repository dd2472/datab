package com.dnapass.training.javaee.listeners;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.dnapass.training.javaee.dao.BookDBAO;
import com.dnapass.training.javaee.util.Counter;


import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;



import com.dnapass.training.javaee.dao.BookDBAO;
import com.dnapass.training.javaee.dao.JDBCUtil;

public final class ContextListener implements ServletContextListener{
	
	private ServletContext context=null;
	
	public void ContextInitialized(ServletContextEvent event) {
		context=event.getServletContext();
		
		Counter counter=new Counter();
		context.setAttribute("hitCounter", counter);
		counter=new Counter();
		context.setAttribute("orderCounter", counter);
		
		try {
			//BookDBA) bookDb=new BookDBAO(emf);
			BookDBAO bookDB=new BookDBAO(JDBCUtil.getConnection());
			context.setAttribute("bookDB", bookDB);
		} catch (Exception ex) {
			System.out.println("couldn't create bookstore bean:"+ex.getMessage());
	}
		
		public void contextDestroyed(ServletContextEvent event) {
	        context = event.getServletContext();
	        BookDBAO bookDB = (BookDBAO) context.getAttribute("bookDB");
	        bookDB.remove();
	        context.removeAttribute("bookDB");
	        context.removeAttribute("hitCounter");
	        context.removeAttribute("orderCounter");
	    }
	}
	

}