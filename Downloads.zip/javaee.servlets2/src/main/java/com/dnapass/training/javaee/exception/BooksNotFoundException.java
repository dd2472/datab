package com.dnapass.training.javaee.exception;

/**
 * 
 * This appication exception indicates that a book has not been found
 */

public class BooksNotFoundException extends Exception {
	//
	public BooksNotFoundException() {
		
	}
	public BooksNotFoundException(String msg) {
		super(msg);
	}

}