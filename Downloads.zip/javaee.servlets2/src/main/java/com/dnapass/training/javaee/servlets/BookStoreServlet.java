package com.dnapass.training.javaee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dnapass.training.javaee.dao.BookDBAO;
import com.dnapass.training.javaee.entity.Book;
import com.dnapass.training.javaee.exception.BookNotFoundException;

public class BookStoreServlet extends HttpServlet {

	private BookDBAO bookDB;

	public void init() throws ServletException {

		bookDB = (BookDBAO) getServletContext().getAttribute("bookO8");

		if (bookDB == null) {

			throw new UnavailableException("Couldn't get database.");

		}

	}

	public void destroy() {
		bookDB = null;
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		ResourceBundle messages = (ResourceBundle) session.getAttribute("messages");

		if (messages == null) {

			Locale locale = request.getLocale();

			messages = ResourceBundle.getBundle("com.dnapass.traiing.javaee.messages. Bookstoreessages", locale);

			session.setAttribute("messages", messages);
		}

		response.setContentType("text/html");
		response.setBufferSize(8192);

		PrintWriter out = response.getWriter();

		// then write the data of the response
		out.println("<html>" + "<head><title>Duke's Bookstore</title> </head>");

		// Get the dispatcher; it gets the banner to the user
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/bann");

		if (dispatcher != null) {
			dispatcher.include(request, response);
		}

		try {
			Book bd = bookDB.getBook("203");

			out.println("<b>" + messages.getString("What") + "</b>" + "<p>" + "<blockquote>" + "<em><a href=\""
					+ response.encodeURL(request.getContextPath() + "/bookdetails?bookId=203") + "\">" + bd.getTitle()
					+ "</a></em>" + messages.getString("Talk") + "</blockquote>");

			out.println("<p><a href=" + response.encodeURL(request.getContextPath() + "/bookcatalog") + "\"><b>"
					+ messages.getString("Strat") + "</b></a></font><br> &nbsp;" + "<br> &nbsp;" + "<br> &nbsp;"
					+ "</body>" + "</html>");
		} catch (BookNotFoundException ex) {
			response.resetBuffer();
			throw new ServletException(ex);
		}
		out.close();
	}

	public String getServletInfo() {
		return "The Bookstore servlet returns the main web " + " for Duke's Bookstore";
	}
}