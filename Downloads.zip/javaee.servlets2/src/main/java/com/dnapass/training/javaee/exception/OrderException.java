package com.dnapass.training.javaee.exception;

/**
 * 
 * This appication exception indicates that a book has not been found
 */

public class OrderException extends Exception {
	//
	public OrderException() {
		
	}
	public OrderException(String msg) {
		super(msg);
	}

}
