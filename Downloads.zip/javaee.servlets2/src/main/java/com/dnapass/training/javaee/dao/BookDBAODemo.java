package com.dnapass.training.javaee.dao;

import java.sql.Connection;
import java.sql.SQLException;
import com.dnapass.training.javaee.dao.BookDBAO;
import com.dnapass.training.javaee.dao.JDBCUtil;

public class BookDBAODemo {
	public static void main(String[] args) {
		Connection myConnection = null;
		try {
			BookDBAO bookDBAO = new BookDBAO(JDBCUtil.getConnection());
			bookDBAO.createTable();
			bookDBAO.populateTable();
			System.out.println("\nContents of WEB_BOOKSTORE BOOKS table: ");

			bookDBAO.viewTable();
			// bookDBAO.dropTable();

		} catch (SQLException e) {

			JDBCUtil.printSQLException(e);

		} catch (ClassNotFoundException e) {

			e.printStackTrace();

		} finally {

			JDBCUtil.closeConnection(myConnection);
		}

	}
}
