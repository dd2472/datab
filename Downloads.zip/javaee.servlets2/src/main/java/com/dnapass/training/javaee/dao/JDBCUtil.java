package com.dnapass.training.javaee.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.dnapass.training.javaee.entity.Messages;



public class JDBCUtil {
	public static Connection getConnection() throws SQLException, ClassNotFoundException {
   
	Connection conn=null;
	
    Class.forName("com.mysql.jdbc.Driver");
    
    conn=DriverManager.getConnection(Messages.getString("url"), Messages.getString("user"),
    		Messages.getString("password"));
    
    return conn;
    
	}
	
	public static void printSQLException(SQLException ex) {
		for(Throwable e:ex) {
			if(e instanceof SQLException) {
				if(ignoreSQLException(((SQLException e))))
			}
		}
	}

}
 