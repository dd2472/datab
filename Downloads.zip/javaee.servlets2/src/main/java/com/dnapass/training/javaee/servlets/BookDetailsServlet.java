package com.dnapass.training.javaee.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ResourceBundle;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dnapass.training.javaee.dao.BookDBAO;
import com.dnapass.training.javaee.entity.Book;
import com.dnapass.training.javaee.exception.BookNotFoundException;
import com.dnapass.training.javaee.util.Currency;

public class BookDetailsServlet extends HttpServlet {
	private BookDBAO bookDB;

	public void init() throws ServletException {
		bookDB = (BookDBAO) getServletContext().getAttribute("bookDB");

		if (bookDB == null) {
			throw new UnavailableException("Couldn't get database.");
		}

	}

	public void destroy() {
		bookDB = null;

	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		ResourceBundle messages = (ResourceBundle) session.getAttribute("messages");

		response.setContentType("text/html");
		response.setBufferSize(8192);

		PrintWriter out = response.getWriter();

		out.println("<html>" + "<head><title>" + messages.getString("TitleBookDescription") + "</title></head>");

		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/banner");

		if (dispatcher != null) {
			dispatcher.include(request, response);
		}

		String bookId = request.getParameter("bookId");

		if (bookId != null) {

			// and the information about the book

			try {

				Book bd = bookDB.getBook(bookId);
				Currency c = (Currency) session.getAttribute("currency");

				if (c == null) {

					c = new Currency();
					c.setLocale(request.getLocale());
					session.setAttribute("currency", c);
				}
				c.setAmount(bd.getPrice());

				// Print out the information obtained

				out.println("<h2>" + bd.getTitle() + "</h2>" + "&nbsp;" + messages.getString("By") + "<em>"

						+ bd.getFirstName() + " " + bd.getSurName() + "</em> &nbsp; &nbsp; " + "("
						+ bd.getCalender_year() + ")<br> &nbsp; <br>" + "<h4>" + messages.getString("Critics")
						+ " </h4>" + "<blockquote>" + bd.getDescription() + "</blockquote>" + "<h4>"
						+ messages.getString("Price") + c.getFormat() + "</h4>" + "<p><strong><a href=\""
						+ response.encodeURL(request.getContextPath() + "/bookcatalog?bookId=" + bookId) + "\">"
						+ messages.getString("CartAdd") + "</a>&nbsp;&nbsp; &nbsp;" + "<a href=\""
						+ response.encodeURL(request.getContextPath() + "/bookcatalog") + "\">"
						+ messages.getString("ContinueShopping") + "</a></p></strong>");
			} catch (BookNotFoundException ex) {
				response.resetBuffer();
				throw new ServletException(ex);

			}
		}
		out.println("</body></html>");
		out.close();
	}

	public String getServletInfo() {
		return "The BookDetail servlet returns information about" + "any book that is available from bookstore";
	}
}