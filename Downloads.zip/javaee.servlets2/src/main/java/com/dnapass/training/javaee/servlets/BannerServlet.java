package com.dnapass.training.javaee.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//This is a simple example of an HTTP Servlet.

public class BannerServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) {

		try {

			output(request, response);

		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block.
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		output(request, response);

	}

	private void output(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		// then write the data of the response

		StringBuilder sb = new StringBuilder();
		/*
		 * sb.append(" <HTML>"); sb.append("<HEAD>");
		 * 
		 * sb.append("</HEAD>"); sb.append("<BODY>");
		 * 
		 * sb.append("</BODY>"); sb.append("</HTML>");
		 * 
		 * out.println(sb.toString());
		 */

		out.println("<body bgcolor=\"#ffffff\">" + "<center>" + "<hr> <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + "<h1>"

				+ "<font size=\"+3\" color=\"#CC0866\">Duke's </font> <img src=\"" + request.getContextPath()

				+ "/duke.books.gif\" alt=\"Duke holding books\"\">"
				+ "<font size=\"+3\" color=\"black\">Bookstore</font>" + "</h1>" + "</center>"
				+ "<br> &nbsp; <hr> <br> ");

	}
}