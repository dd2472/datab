CREATE TABLE WEB_BOOKSTORE_BOOKS  
 (bookId VARCHAR(8),  
surname VARCHAR(24),  
firstName VARCHAR(24),  
 title VARCHAR(96),  
price FLOAT,  
 onSale SMALLINT,  
calendar_year INT, 
description VARCHAR (30), 
 inventory INT);
 

INSERT INTO WEB BOOKSTORE BOOKS VALUES  ('201', 'Duke','', 'My Early Years: Growing up on 7', 38.75, 0, 1995, 'What a cool book',20); 
INSERT INTO WEB BOOKSTORE BOOKS VALUES ('202,'Jeeves','',  'Web Servers for Fun and Profit', 48.75, 1, 2008, 'What a cool book',13 );
INSERT INTO WEB BOOKSTORE BOOKS VALUES ('203', 'Masterson', 'Webster', 'Web Components for Web Developers', 27.75, 0,2,1998,'what a cool book',12);
INSERT INTO WEB_BOOKSTORE BOOKS VALUES ('205', 'Novation', 'Kevin', 'From Oak to Java: The Revolution of a Language', 1 ,2007,'what a cool book',15)
INSERT INTO WEB BOOKSTORE BOOKS VALUES ('206', 'Gosling', 'James', 'Java Intermediate Bytecodes', 30.95, 1, 2000, 'What a cool book',19)
INSERT INTO WEB BOOKSTORE BOOKS VALUES('207', Thrilled','Ben','The Green Proiect: Programming for consumer devices',20.98,2,2004,'what a cool book',32)
